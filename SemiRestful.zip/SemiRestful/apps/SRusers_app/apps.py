from __future__ import unicode_literals

from django.apps import AppConfig


class SrusersAppConfig(AppConfig):
    name = 'SRusers_app'
